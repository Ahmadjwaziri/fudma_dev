<?php


class ResponseData
{
    public $id; //String
    public $description; //String
    public $label; //String
}