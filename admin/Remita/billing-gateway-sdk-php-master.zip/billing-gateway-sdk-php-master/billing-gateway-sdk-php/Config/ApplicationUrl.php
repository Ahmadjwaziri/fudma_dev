<?php


class ApplicationUrl
{
    public static $demoUrlGetBillers='https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/billers';

    public static $liveUrlGetBillers='https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/billers';

    public static $demoUrlGetServices='https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/';

    public static $liveUrlGetServices='https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/';

    public static $demoUrlGetCustomFields='https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/servicetypes/';

    public static $liveUrlGetCustomFields='https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/servicetypes/';

    public static $demoUrlGetRRRDetails= 'https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/lookup/';

    public static $liveUrlGetRRRDetails= 'https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/lookup/';

    public static $demoUrlGenerateRRR= 'https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/generate';

    public static $liveUrlGenerateRRR= 'https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/generate';

    public static $demoUrlValidateRRR= 'https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/validate';

    public static $liveUrlValidateRRR= 'https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/validate';

    public static $demoUrlPaymentNotification= 'https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/payment/notify';

    public static $liveUrlPaymentNotification= 'https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/payment/notify';

    public static $demoUrlPaymentStatus= 'https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/payment/status/';

    public static $liveUrlPaymentStatus= 'https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/payment/status/';

    public static $demoUrlPrintReceipt= 'https://remitademo.net/remita/exapp/api/v1/send/api/bgatesvc/billing/{publicKey}/{rrr}/{requestId}/rest.reg';

    public static $liveUrlPrintReceipt= 'https://login.remita.net/remita/exapp/api/v1/send/api/bgatesvc/billing/{publicKey}/{rrr}/{requestId}/rest.reg';










}