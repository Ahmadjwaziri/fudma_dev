<?php


class ExtendedData
{

}